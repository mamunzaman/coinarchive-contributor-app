import { DuplicateWarningCard } from './DuplicateWarningCard'
import { SafeHtmlContent } from '../ui/SafeHtmlContent'
import { computeCompletenessScore } from '../../lib/completenessScore'
import type { DuplicateMatch } from '../../lib/duplicateDetection'
import { formatRecordStatusLabel, formatStatusBoolean } from '../../lib/revisionComparison'
import { formatMintMarkDisplay, type CoinFormValues } from '../../types/coinForm'
import {
  EMPTY_FORM_OPTIONS,
  isKnownTaxonomyOption,
  type FormOptions,
} from '../../types/formOptions'

const TAXONOMY_REVIEW_STALE_MESSAGE =
  'This taxonomy value is no longer available. Please choose a valid option before submitting.'

type ReviewSubmissionStepProps = {
  values: CoinFormValues
  isAdmin?: boolean
  formOptions?: FormOptions
  formOptionsReady?: boolean
  duplicateMatches: DuplicateMatch[]
  obversePreviewUrl?: string | null
  reversePreviewUrl?: string | null
  galleryPreviewUrls?: string[]
  hasExistingObverse?: boolean
  hasExistingReverse?: boolean
  existingGalleryUrls?: string[]
}

function DetailRow({ label, value }: { label: string; value: string }) {
  if (!value.trim()) {
    return null
  }

  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wide text-navy-muted">{label}</dt>
      <dd className="mt-1 text-sm text-navy">{value}</dd>
    </div>
  )
}

function DetailHtmlRow({ label, value }: { label: string; value: string }) {
  if (!value.trim()) {
    return null
  }

  return (
    <div>
      <dt className="text-xs font-semibold uppercase tracking-wide text-navy-muted">{label}</dt>
      <dd className="mt-1 text-sm text-navy">
        <SafeHtmlContent html={value} />
      </dd>
    </div>
  )
}

function isStaleTaxonomyValue(
  value: string,
  options: FormOptions['countries'],
  formOptionsReady: boolean,
): boolean {
  const trimmed = value.trim()
  return (
    formOptionsReady &&
    options.length > 0 &&
    Boolean(trimmed) &&
    !isKnownTaxonomyOption(trimmed, options)
  )
}

export function ReviewSubmissionStep({
  values,
  isAdmin = false,
  formOptions = EMPTY_FORM_OPTIONS,
  formOptionsReady = false,
  duplicateMatches,
  obversePreviewUrl,
  reversePreviewUrl,
  galleryPreviewUrls = [],
  hasExistingObverse = false,
  hasExistingReverse = false,
  existingGalleryUrls = [],
}: ReviewSubmissionStepProps) {
  const hasObverse = Boolean(obversePreviewUrl || hasExistingObverse)
  const hasReverse = Boolean(reversePreviewUrl || hasExistingReverse)
  const hasGallery = galleryPreviewUrls.length > 0 || existingGalleryUrls.length > 0

  const completeness = computeCompletenessScore({
    values,
    hasObverse,
    hasReverse,
    hasGallery,
  })

  const mintSummary = values.hasMintVariants
    ? values.mintVariants
        .filter((row) => row.mintMarkCode.trim() || row.mintMintage.trim() || row.mintNotes.trim())
        .map(
          (row) =>
            `${formatMintMarkDisplay(row.mintMarkCode) || '—'} · mintage ${row.mintMintage || '—'}${row.mintNotes ? ` · ${row.mintNotes}` : ''}`,
        )
        .join('; ')
    : values.singleMintMark.trim()

  const allGalleryUrls = [...galleryPreviewUrls, ...existingGalleryUrls]

  const staleTaxonomyWarnings = [
    {
      label: 'Country',
      stale: isStaleTaxonomyValue(values.country, formOptions.countries, formOptionsReady),
    },
    {
      label: 'Denomination',
      stale: isStaleTaxonomyValue(values.denomination, formOptions.values, formOptionsReady),
    },
    {
      label: 'Coin type',
      stale: isStaleTaxonomyValue(values.coin_type, formOptions.types, formOptionsReady),
    },
  ].filter((item) => item.stale)

  return (
    <section className="flex flex-col gap-6">
      <DuplicateWarningCard matches={duplicateMatches} prominent />

      <div className="rounded-xl border border-border/60 bg-muted/20 p-4">
        <p className="text-sm font-medium text-navy">Review your submission before sending for archive review.</p>
      </div>

      <div>
        <h3 className="font-serif text-lg font-semibold text-navy">Images</h3>
        <div className="mt-4 grid gap-4 sm:grid-cols-2">
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-navy-muted">Obverse</p>
            {obversePreviewUrl ? (
              <img
                src={obversePreviewUrl}
                alt="Obverse review"
                className="aspect-square w-full rounded-xl border border-border/60 bg-white object-contain p-2"
              />
            ) : (
              <p className="text-sm text-navy-muted">No obverse image</p>
            )}
          </div>
          <div>
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-navy-muted">Reverse</p>
            {reversePreviewUrl ? (
              <img
                src={reversePreviewUrl}
                alt="Reverse review"
                className="aspect-square w-full rounded-xl border border-border/60 bg-white object-contain p-2"
              />
            ) : (
              <p className="text-sm text-navy-muted">No reverse image</p>
            )}
          </div>
        </div>
        {allGalleryUrls.length > 0 ? (
          <div className="mt-4">
            <p className="mb-2 text-xs font-semibold uppercase tracking-wide text-navy-muted">Gallery</p>
            <div className="grid grid-cols-2 gap-3 sm:grid-cols-4">
              {allGalleryUrls.map((url, index) => (
                <img
                  key={`${url}-${index}`}
                  src={url}
                  alt={`Gallery ${index + 1}`}
                  className="aspect-square rounded-lg border border-border/60 bg-white object-contain p-1"
                />
              ))}
            </div>
          </div>
        ) : null}
      </div>

      <div>
        <h3 className="font-serif text-lg font-semibold text-navy">Taxonomy</h3>
        <dl className="mt-4 grid gap-4 sm:grid-cols-2">
          <DetailRow label="Country" value={values.country} />
          <DetailRow label="Denomination" value={values.denomination} />
          <DetailRow label="Coin type" value={values.coin_type} />
        </dl>
        {staleTaxonomyWarnings.length > 0 ? (
          <div
            role="alert"
            className="mt-4 rounded-xl border border-amber-200 bg-amber-50 px-4 py-3 text-sm text-amber-950"
          >
            <p className="font-semibold">Taxonomy needs attention</p>
            <ul className="mt-2 list-disc space-y-1 pl-5">
              {staleTaxonomyWarnings.map((item) => (
                <li key={item.label}>
                  <span className="font-medium">{item.label}:</span> {TAXONOMY_REVIEW_STALE_MESSAGE}
                </li>
              ))}
            </ul>
          </div>
        ) : null}
      </div>

      <div>
        <h3 className="font-serif text-lg font-semibold text-navy">Coin details</h3>
        <dl className="mt-4 grid gap-4 sm:grid-cols-2">
          <DetailRow label="Title" value={values.title} />
          <DetailRow label="Year" value={values.year} />
          <DetailRow label="Theme" value={values.coin_theme} />
        </dl>
      </div>

      {mintSummary ? (
        <div>
          <h3 className="font-serif text-lg font-semibold text-navy">Mint information</h3>
          <p className="mt-2 text-sm text-navy">{mintSummary}</p>
        </div>
      ) : null}

      {isAdmin ? (
        <div>
          <h3 className="font-serif text-lg font-semibold text-navy">Status & visibility</h3>
          <dl className="mt-4 grid gap-4 sm:grid-cols-2">
            <DetailRow
              label="Published in catalogue"
              value={formatStatusBoolean(values.coin_is_published_catalogue)}
            />
            <DetailRow label="Featured coin" value={formatStatusBoolean(values.coin_is_featured)} />
            <DetailRow label="App enabled" value={formatStatusBoolean(values.coin_is_app_enabled)} />
            <DetailRow
              label="Record status"
              value={formatRecordStatusLabel(values.coin_record_status)}
            />
          </dl>
        </div>
      ) : null}

      <div>
        <h3 className="font-serif text-lg font-semibold text-navy">Description</h3>
        <p className="mt-2 whitespace-pre-wrap text-sm text-navy">
          {values.short_description || 'No short description provided.'}
        </p>
      </div>

      {values.coin_historical_background.trim() ? (
        <div>
          <h3 className="font-serif text-lg font-semibold text-navy">Historical background</h3>
          <div className="mt-2 text-sm text-navy">
            <SafeHtmlContent html={values.coin_historical_background} />
          </div>
        </div>
      ) : null}

      {(values.coin_obverse_description.trim() ||
        values.coin_reverse_description.trim() ||
        values.coin_collector_notes.trim()) ? (
        <div>
          <h3 className="font-serif text-lg font-semibold text-navy">Additional notes</h3>
          <dl className="mt-4 grid gap-4">
            <DetailHtmlRow label="Obverse" value={values.coin_obverse_description} />
            <DetailHtmlRow label="Reverse" value={values.coin_reverse_description} />
            <DetailHtmlRow label="Collector notes" value={values.coin_collector_notes} />
          </dl>
        </div>
      ) : null}

      {completeness.missingRecommended.length > 0 ? (
        <div className="rounded-xl border border-amber-200 bg-amber-50 px-4 py-4">
          <p className="text-sm font-semibold text-amber-950">Missing recommended fields</p>
          <ul className="mt-2 list-disc space-y-1 pl-5 text-sm text-amber-900">
            {completeness.missingRecommended.map((item) => (
              <li key={item}>{item}</li>
            ))}
          </ul>
        </div>
      ) : null}

      <p className="text-xs text-navy-muted">
        Use <strong>Back</strong> to edit any section, or <strong>Submit for review</strong> when ready.
      </p>
    </section>
  )
}
